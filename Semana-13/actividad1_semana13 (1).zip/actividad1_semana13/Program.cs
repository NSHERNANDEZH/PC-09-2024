﻿using System;

namespace actividad1_semana13
{
    class ArregloUnidimensional
    {
        private string[] nombres;
        private string[] apellidos;
        private int[] edades;
        private string[] telefonos;
        public void Cargar()
        {
            nombres = new string[4];
            apellidos = new string[4];
            edades = new int[4];
            telefonos = new string[4];

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Ingrese los datos de la persona {i + 1}:");
                Console.Write("Nombre: ");
                nombres[i] = Console.ReadLine();
                Console.Write("Apellido: ");
                apellidos[i] = Console.ReadLine();
                Console.Write("Edad: ");
                edades[i] = int.Parse(Console.ReadLine());
                Console.Write("Teléfono: ");
                telefonos[i] = Console.ReadLine();
            }
        }

        public void Imprimir()
        {
            Console.WriteLine("");
            Console.WriteLine($"datos de los clientes:");

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Persona {i + 1} Nombre: {nombres[i]} Apellido: {apellidos[i]} Edad: {edades[i]} Teléfono: {telefonos[i]}");
            }
            Console.ReadKey();
        }

        static void Main()
        {
            ArregloUnidimensional arregloUnidimensional_ = new ArregloUnidimensional();
            arregloUnidimensional_.Cargar();
            arregloUnidimensional_.Imprimir();
        }
    }
}
