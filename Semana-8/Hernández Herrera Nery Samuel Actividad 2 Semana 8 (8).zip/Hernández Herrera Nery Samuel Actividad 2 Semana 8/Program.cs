﻿using System;

class ht
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese un número entero mayor a cero, no mayor a 6 cifras:");
        int numero = Convert.ToInt32(Console.ReadLine());

        // Se comprueba que el número se mantenga dentro de las 6 cifras
        if (numero <= 0 || numero > 999999)
        {
            Console.WriteLine("Error: El número ingresado no es válido.");
            return;
        }

        bool esPrimo = true;

        // Si el número es menor o igual a 1, no es primo
        if (numero <= 1)
        {
            esPrimo = false;
        }
        else
        {
            // Iterar desde 2 hasta la raíz cuadrada de numero
            for (int divisor = 2; divisor <= Math.Sqrt(numero); divisor++)
            {
                if (numero % divisor == 0)
                {
                    // Si se encuentra un divisor, el número es compuesto
                    esPrimo = false;
                    break;
                }
            }
        }

        if (esPrimo)
        {
            Console.WriteLine("El número es primo.");
        }
        else
        {
            Console.WriteLine("El número es compuesto.");
        }
    }
}
