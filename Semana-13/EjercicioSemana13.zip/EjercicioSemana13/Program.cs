﻿

namespace Arreglos
{
    class Program
    {
        private int[] numeros;

        public void SolicitarNumeros()
        {
            numeros = new int[8];

            for (int i = 0; i < 8; i++)
            {
                Console.Write($"Ingrese el número {i + 1}: ");
                string linea = Console.ReadLine();
                numeros[i] = int.Parse(linea);
            }
        }

        public void MostrarNumeros()
        {
            Console.WriteLine("\nNúmeros ingresados:");
            for (int i = 0; i < 8; i++)
            {
                Console.WriteLine($"Número {i + 1}: {numeros[i]}");
            }
        }

        public void MostrarSuma()
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            Console.WriteLine($"La suma de los números es: {suma}");
        }

        public void MostrarPromedio()
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            double promedio = (double)suma / 8;
            Console.WriteLine($"El promedio de los números es: {promedio}");
        }

        static void Main()
        {
            Program programa = new Program();
            programa.SolicitarNumeros();
            programa.MostrarNumeros();
            programa.MostrarSuma(); 
            programa.MostrarPromedio();
            Console.ReadKey();
        }
    }
}

           
