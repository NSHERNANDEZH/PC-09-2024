﻿using System;
 
public class Hernandez
{
    // propiedades
    int numero;
    string cadena;
    int numero2;
 
    public static void Main()
    {
        Hernandez  objetoProgram = new Hernandez(3, "hola", 2 );
        objetoProgram.show();

            string entrada;
        Console.WriteLine("Por favor ingrese una opción (1 para Ingreso de valores, 2 para Mostrar valores, 3 para Salir del programa):");
        entrada = Console.ReadLine();

        int opcion;
        if (!int.TryParse(entrada, out opcion))
        {
            Console.WriteLine("Entrada no válida. Debe ingresar un número entero.");
            return;
        }

        switch (opcion)
        {
            case 1:
                Console.WriteLine("Ingreso de valores");
                break;
            case 2:
                Console.WriteLine("Mostrar valores");
                break;
            case 3:
                Console.WriteLine("Salir del programa");
                System.Threading.Thread.Sleep(1000);
                break;
            default:
                Console.WriteLine("Opción no válida. Debe ingresar un número entre 1 y 3.");
                break;
        }
    }
 
    Hernandez (int numero, string cadena, int numero2)
    {
        this.numero = numero;
        this.cadena = cadena;
        this.numero2 = numero2;
    }
 
    // metodos de la clase    

    
    void show()
    {
        Console.WriteLine(this.numero);
        Console.WriteLine(this.cadena);
        Console.WriteLine(this.numero2);
        Console.ReadKey();
    }
}