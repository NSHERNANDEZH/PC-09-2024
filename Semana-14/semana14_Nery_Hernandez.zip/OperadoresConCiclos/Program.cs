﻿
namespace Arreglos
{
    class Program
    {
        private int[]? numeros;

        public void SolicitarNumeros()
        {
            numeros = new int[12];

            for (int i = 0; i < 12; i++)
            {
                Console.Write($"Ingrese el número {i + 1}: ");
                string linea = Console.ReadLine();
                numeros[i] = int.Parse(linea);
            }
        }

        public void Menu()
        {
            Console.WriteLine("Seleccione una opción");
            Console.WriteLine("1. Mostrar números ingresados");
            Console.WriteLine("2. Calcular suma de los números");
            Console.WriteLine("3. Calcular promedio de los números");
            Console.WriteLine("4. Mostrar números en orden ascendente");
            Console.WriteLine("5. Mostrar números en orden descendente");
            Console.WriteLine("6. Cambiar tamaño de arreglo");
            Console.WriteLine("7. Salir");

            int opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    MostrarNum();
                    break;
                case 2:
                    MostrarSum();
                    break;
                case 3:
                    MostrarProm();
                    break;
                case 4:
                    Ascendente();
                    break;
                case 5:
                    Descendente();
                    break;
                case 6:
                    CambiarTamaño();
                    break;
                case 7:
                    Console.WriteLine("Saliendo...");
                    break;
                default:
                    Console.WriteLine("Opción inválida");
                    break;
            }
        }

        public void MostrarNum()
        {
            Console.WriteLine("\nNúmeros ingresados:");
            for (int i = 0; i < 12; i++)
            {
                Console.WriteLine($"Número {i + 1}: {numeros[i]}");
            }
        }

        public void MostrarSum()
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            Console.WriteLine($"La suma de los números es: {suma}");
        }

        public void MostrarProm()
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            double promedio = (double)suma / 12;
            Console.WriteLine($"El promedio de los números es: {promedio}");
        }

        public void Descendente()
        {
            Array.Sort(numeros);
            Array.Reverse(numeros);
            Console.WriteLine("\nNúmeros en orden descendente:");
            foreach (int num in numeros)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
        }

        public void Ascendente()
        {
            Array.Sort(numeros);
            Console.WriteLine("\nNúmeros en orden ascendente:");
            foreach (int num in numeros)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
        }

        static void Main()
        {
            Program programa = new Program();
            programa.SolicitarNumeros();
            bool continuar = true;
            while (continuar)
            {
                programa.Menu();
                Console.Write("\n¿Desea realizar otra operación? (si/no): ");
                string respuesta = Console.ReadLine();
                if (respuesta.ToLower() != "si")
                {
                    continuar = false;
                }
            }
            Console.WriteLine("Programa finalizado.");
            Console.ReadKey();
        }

        public void CambiarTamaño()
        {
            Array.Resize(ref numeros, numeros.Length + 2);
            Console.WriteLine("Se agregaron dos números");
            MostrarNum();


        }
    }
}
